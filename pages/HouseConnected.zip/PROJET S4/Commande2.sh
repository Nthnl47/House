sshpass -p "houseconnected" ssh -o StrictHostKeyChecking=no pi@192.168.43.107 './motion.sh'







