#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Launcher.h"


void launch(char *adressIP,char *password,char *script)
{
 char cmd[512];
 sprintf(cmd, "sshpass -p %s ssh -o StrictHostKeyChecking=no %s %s\n",adressIP,password,script);

 system(cmd);
}

