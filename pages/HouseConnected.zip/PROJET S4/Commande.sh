sshpass -p "houseconnected" ssh -o StrictHostKeyChecking=no pi@172.20.10.6 './motion.sh'
