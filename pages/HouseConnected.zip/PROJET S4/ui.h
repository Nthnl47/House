#ifndef UI_H_
#define UI_H_

#include "Launcher.h"
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>


int LaunchUserInterface(int argc, char **argv);

#endif
