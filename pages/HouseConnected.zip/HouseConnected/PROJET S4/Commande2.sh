sshpass -p "houseconnected" ssh -o StrictHostKeyChecking=no pi@172.20.10.6 './Sweep no no no no yes yes no no no 22'







