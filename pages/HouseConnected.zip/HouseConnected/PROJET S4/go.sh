gcc `pkg-config gtk+-3.0 --cflags` -g ui.c -o HouseConnected `pkg-config gtk+-3.0 --libs` -rdynamic -pthread

