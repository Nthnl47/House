#ifndef LAUNCHER_H_
#define LAUNCHER_H_

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

void launch(char *adressIP,char *password,char *script);

#endif
