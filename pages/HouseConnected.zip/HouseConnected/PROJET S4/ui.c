#include "ui.h"
#include "pthread.h"
#include "err.h"
#include <string.h>

pthread_t thr1,thr2;
GtkImage *image;
GtkStack *stack;
GtkStack *stack2;
GtkWidget *window = NULL;
GtkBuilder *builder;
GtkLabel *connection_status;
GtkLabel *step1_status;
GtkLabel *adressIP_label;
GtkLabel *water_label;
GtkLabel *heat_label;
GtkLabel *light_label;
GtkLabel *alarm_label;
GtkLabel *shutters_label;
GtkSpinner *step_connection;
GtkSpinner *step_connection1;
GtkSpinner *step_connection2;
GtkSpinner *step_connection3;
// buttons
GtkWidget *checklight;
GtkWidget *checkwater;
GtkWidget *checkalarm;
GtkWidget *checkheat;
GtkWidget *checkshut;
GtkWidget *checkhere;
GtkWidget *checklongtimenothere;
GtkWidget *checknight;
GtkWidget *checkraining;

//GtkWidget *check;
GtkWidget *load_button;
GtkWidget *website_button;
GtkWidget *step1_button;
GtkWidget *show_button;
GtkWidget *lock_button4;


// entry widgets
GtkWidget *adressIP_entry;
GtkWidget *mdp_entry;
GtkWidget *temp_entry;
// text from entry slots
const gchar *adressIP_text;
const gchar *mdp_text;
const gchar *temp_text;
char here[10]="no";
char longtimenothere[10]="no";
char night[10]="no";
char raining[10]="no";  
char arg1[10]="no";
char arg2[10]="no";
char arg3[10]="no";
char arg4[10]="no"; 
char arg5[10]="no";

void flaunch(const gchar *adressIP,const gchar *password)
{
	int e;
	char lCmd[512]; 
	
	
	temp_text = gtk_entry_get_text(GTK_ENTRY(temp_entry));    
    
    
	sprintf(lCmd, "sshpass -p %s ssh -o StrictHostKeyChecking=no pi@%s ./Sweep %s %s %s %s %s %s %s %s %s %s\n",password,adressIP,arg1,arg2,arg3,arg4,arg5,here,longtimenothere,night,raining,temp_text);
	system(lCmd);
 	gtk_label_set_label (connection_status,"✅  Connected ");	
}

void Quit()
{
    gtk_main_quit();
    gtk_widget_destroy(GTK_WIDGET(window));
}

void Website()
{
    // Open the website
    system("firefox https://nthnl47.github.io/House/page_accueil.html");
}

void show_page(GtkWidget *widget, gpointer data)
{
    // Avoid warning
    (void)widget;

    GtkWidget *page = data;
    gtk_stack_set_visible_child(stack, page);
}

void show_page2(GtkWidget *widget, gpointer data)
{
    // Avoid warning
    (void)widget;

    GtkWidget *page = data;
    gtk_stack_set_visible_child(stack2, page);
}



void show_page3(GtkWidget *widget, gpointer data)
{
    (void)widget;
    if (adressIP_text==NULL || mdp_text==NULL)
    {
        gtk_label_set_label (step1_status,"You did not enter an IP address or password");
    }
    else
    {
            GtkWidget *page = data;
            gtk_stack_set_visible_child(stack2, page);
            gtk_spinner_stop(step_connection);
            gtk_spinner_start(step_connection1);

    }
    }



void show_page4(GtkWidget *widget, gpointer data)
{	(void)widget;
   	GtkWidget *page = data;
        gtk_stack_set_visible_child(stack2, page);
        gtk_spinner_stop(step_connection1);
        gtk_spinner_start(step_connection2);
        
}
void show_page5(GtkWidget *widget, gpointer data)
{	(void)widget;
    GtkWidget *page = data;
    gtk_stack_set_visible_child(stack2, page);
    gtk_spinner_stop(step_connection2);
    gtk_spinner_start(step_connection3);
    gtk_label_set_label(adressIP_label,adressIP_text);	

        if (gtk_toggle_button_get_active((GtkToggleButton *)checkhere)==TRUE)
        {
            strcpy(here,"yes");         
        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checklongtimenothere)==TRUE)
        {
            strcpy(longtimenothere,"yes");          
        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checknight)==TRUE)
        {
            strcpy(night,"yes");        
        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checkraining)==TRUE)
        {
            strcpy(raining,"yes");          
        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checklight)==TRUE)
        {
            strcpy(arg1,"yes");
            gtk_widget_show((GtkWidget*)light_label);
        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checkwater)==TRUE)
        {
            strcpy(arg2,"yes");
            gtk_widget_show((GtkWidget*)water_label);

        }
    if (gtk_toggle_button_get_active((GtkToggleButton *)checkalarm)==TRUE)
        {
            strcpy(arg3,"yes");
            gtk_widget_show((GtkWidget*)alarm_label);

        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checkheat)==TRUE)
        {
            strcpy(arg4,"yes");
            gtk_widget_show((GtkWidget*)heat_label);

        }
        if (gtk_toggle_button_get_active((GtkToggleButton *)checkshut)==TRUE)
        {
            strcpy(arg5,"yes");
             gtk_widget_show((GtkWidget*)shutters_label);
                    
        }
}
void show_page6(GtkWidget *widget, gpointer data)
{	(void)widget;

    GtkWidget *page = data;
    gtk_stack_set_visible_child(stack2, page);
    gtk_spinner_stop(step_connection3);
        
    flaunch(adressIP_text,mdp_text);

     gtk_label_set_label (connection_status,"✅  Connected ");
}
void step1()
{
    g_print("%s\n",adressIP_text);
    g_print("%s\n",mdp_text);
}
void start_button(GtkWidget *widget, gpointer data)
{
    (void)widget;
    GtkWidget *page = data;
    gtk_stack_set_visible_child(stack2, page);
    gtk_spinner_start(step_connection);

}


// +-----------------------------------------------Callback funtions---------------------------------------------------+
gboolean on_adressIP_entry()
{
    adressIP_text = gtk_entry_get_text(GTK_ENTRY(adressIP_entry));
    return FALSE;
}

gboolean on_mdp_entry()
{
    mdp_text = gtk_entry_get_text(GTK_ENTRY(mdp_entry));
    return FALSE;
}

gboolean on_quit(GtkWidget *widget)
{
    Quit();
    return FALSE;
}

gboolean on_website(GtkWidget *widget)
{
    Website();
    return FALSE;
}
gboolean on_step1()
{
    step1();
    return FALSE;
}

int LaunchUserInterface(int argc, char **argv)
{


    gtk_init(NULL, NULL);

    GtkBuilder *builder = gtk_builder_new();

    GError *error = NULL;

    if (gtk_builder_add_from_file(builder, "ui.glade", &error) == 0)
    {
        g_printerr("Error loading file :%s\n", error -> message);
        g_clear_error(&error);
        return 1;
    }
    gtk_builder_connect_signals(builder, NULL);
    window =
        GTK_WIDGET(gtk_builder_get_object(builder, "window")); // get window
        gtk_builder_connect_signals(builder, NULL); // connect signals

	
    checklight = GTK_WIDGET(gtk_builder_get_object(builder, "checklight"));
    checkwater = GTK_WIDGET(gtk_builder_get_object(builder, "checkwater"));
    checkalarm = GTK_WIDGET(gtk_builder_get_object(builder, "checkalarm"));
    checkheat = GTK_WIDGET(gtk_builder_get_object(builder, "checkheat"));
    checkshut = GTK_WIDGET(gtk_builder_get_object(builder, "checkshut"));
    // General settings

    checkhere = GTK_WIDGET(gtk_builder_get_object(builder, "checkhere"));
    checklongtimenothere = GTK_WIDGET(gtk_builder_get_object(builder, "checklongtimenothere"));
    checknight = GTK_WIDGET(gtk_builder_get_object(builder, "checknight"));
    checkraining = GTK_WIDGET(gtk_builder_get_object(builder, "checkraining"));
    	
    	//spinner
    	step_connection = GTK_SPINNER(gtk_builder_get_object(builder, "step_connection"));
    	step_connection1 = GTK_SPINNER(gtk_builder_get_object(builder, "step_connection1"));
        step_connection2 = GTK_SPINNER(gtk_builder_get_object(builder, "step_connection2"));
        step_connection3 = GTK_SPINNER(gtk_builder_get_object(builder, "step_connection3"));
        connection_status = GTK_LABEL(gtk_builder_get_object(builder, "connection_status"));
        adressIP_label = GTK_LABEL(gtk_builder_get_object(builder, "adressIP_label"));
        water_label = GTK_LABEL(gtk_builder_get_object(builder, "water_label"));        
        alarm_label = GTK_LABEL(gtk_builder_get_object(builder, "alarm_label"));        
        heat_label = GTK_LABEL(gtk_builder_get_object(builder, "heat_label"));       
        shutters_label = GTK_LABEL(gtk_builder_get_object(builder, "shutters_label"));       
        light_label = GTK_LABEL(gtk_builder_get_object(builder, "light_label"));              
        step1_status = GTK_LABEL(gtk_builder_get_object(builder, "step1_status"));
        gtk_window_set_title(GTK_WINDOW(window), "House Connected");
        stack2 = GTK_STACK(gtk_builder_get_object(builder, "right_panel"));
        stack = GTK_STACK(gtk_builder_get_object(builder, "window_pages"));
    window = GTK_WIDGET(gtk_builder_get_object(builder, "main"));
    adressIP_entry = GTK_WIDGET(gtk_builder_get_object(builder, "adressIP_entry"));
    temp_entry = GTK_WIDGET(gtk_builder_get_object(builder, "temp_entry"));
    show_button = GTK_WIDGET(gtk_builder_get_object(builder, "show_button"));
    website_button = GTK_WIDGET(gtk_builder_get_object(builder, "website_button"));
    mdp_entry = GTK_WIDGET(gtk_builder_get_object(builder, "mdp_entry"));
    step1_button = GTK_WIDGET(gtk_builder_get_object(builder, "step1_button"));
    lock_button4 = GTK_WIDGET(gtk_builder_get_object(builder, "lock_button4"));
    // CONNEXION DES SIGNAUX
    g_signal_connect(mdp_entry, "changed", G_CALLBACK(on_mdp_entry), NULL);
    g_signal_connect(step1_button, "clicked", G_CALLBACK(on_step1), NULL);
    g_signal_connect(adressIP_entry, "changed", G_CALLBACK(on_adressIP_entry), NULL);
    g_signal_connect(window, "destroy", G_CALLBACK(on_quit), NULL);
    g_signal_connect(website_button, "clicked", G_CALLBACK(on_website), NULL);
    gtk_main();
return 0;
}

int main(int argc, char **argv)
{
    LaunchUserInterface(argc, argv);
    return 0;
}

